from django.db import models

# Create your models here.
class Manufacturer(models.Model):
    name = models.CharField(max_length=100)
    location = models.CharField(max_length=100)
    
class Product(models.Model):
    name = models.CharField(max_length=100)
    batch_number = models.CharField(max_length=100)
    manufacturer = models.ForeignKey(Manufacturer, on_delete=models.CASCADE)
    expiration_date = models.DateTimeField()
    production_date = models.DateTimeField()
    
