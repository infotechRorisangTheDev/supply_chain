from django.shortcuts import render, redirect
from supplychain.forms import ProductForm
from .blockchain import create_block, get_blockchain
from .models import Manufacturer, Product
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.contrib import messages

# Create your views here.
def product_register(request):
    # Authenticate user
    if request.method == 'POST':
        # username = request.POST['username']
        # password = request.POST['password']
        # user = authenticate(request, username=username, password=password)
        # if user is not None:
        #     login(request, user)
        #     messages.success(request, "You Have Been Logged In!")
        #     return redirect('product_list')
        # else:
        #     messages.success(request, "There was an Error Logging You in, Please try again...")
        #     return redirect('product_list')
    
    
        form = ProductForm(request.POST)
        if form.is_valid():
            product = form.save()
            block_data = {
                'name': product.name,
                'batch_number': product.batch_number,
                'manufacturer': product.manufacturer.name,
                'production_date': product.production_date.isoformat(),
                'expiration_date': product.expiration_date.isoformat()
            }
            create_block(block_data)
            return redirect('product_list')
    else:
        form = ProductForm()
    return render(request, 'supplychain/product_register.html', {'form': form})

def product_list(request):
    products = Product.objects.all()
    blockchain_data = get_blockchain()
    return render(request, 'supplychain/product_list.html', {'products': products, 'blockchain': blockchain_data})


def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('product_list')
    else:
        form = AuthenticationForm()
    return render(request, 'supplychain/login.html', {'form': form})

def signup_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('product_list')
    else:
        form = UserCreationForm()
    return render(request, 'supplychain/signup.html', {'form': form})    


def logout_user(request):
    logout(request)
    return redirect('login')