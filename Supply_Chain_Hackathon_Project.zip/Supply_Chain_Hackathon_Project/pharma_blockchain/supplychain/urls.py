from django.urls import path
from .views import product_register, product_list, login_view, signup_view, logout_user

urlpatterns = [
    path('register/', product_register, name='product_register'),
    path('product_list/', product_list, name='product_list'),
    path('', login_view, name='login'),
    path('signup/', signup_view, name='signup'),
    path('logout/', logout_user, name='logout'),
]
