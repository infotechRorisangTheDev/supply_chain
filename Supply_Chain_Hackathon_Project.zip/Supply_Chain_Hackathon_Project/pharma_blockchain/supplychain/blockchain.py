import json

blockchain = []

def create_block(data):
    block = {
        'index': len(blockchain) + 1,
        'data': data,
    }
    blockchain.append(block)
    return block

def get_blockchain():
    return blockchain