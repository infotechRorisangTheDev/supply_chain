from django.contrib import admin
from .models import Supplier, Product, Product_Batch, Order, Stock_control, Dispancing, Demanders, Dispatch, Patients

# Register your models here.

admin.site.register(Supplier)
admin.site.register(Product)
admin.site.register(Product_Batch)
admin.site.register(Order)
admin.site.register(Stock_control)
admin.site.register(Dispancing)
admin.site.register(Demanders)
admin.site.register(Dispatch)
admin.site.register(Patients)