from django.db import models

# Create your models here.
class Supplier(models.Model):
    supplier_name = models.CharField(max_length=100)
    supplier_address = models.CharField(max_length=100)
    supplier_contacts = models.CharField(max_length=13)

    def __str__(self) -> str:
        return self.supplier_name


class Product(models.Model):
    product_name = models.CharField(max_length=100)
    product_quantity = models.IntegerField()
    product_desc = models.CharField(max_length=255)
    supplier = models.ForeignKey(Supplier, on_delete=models.CASCADE)

    def __str__(self) -> str:
        return self.product_name



class Product_Batch(models.Model):
    product_price = models.DecimalField(decimal_places=2, max_digits=6)
    batch_quantity = models.IntegerField()
    product = models.ForeignKey(Product, on_delete=models.CASCADE)

    def __int__(self) -> str:
        return self.batch_quantity


class Order(models.Model):
    order_list = models.CharField(max_length=300)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)

    def __str__(self) -> str:
        return self.order_list


class Stock_control(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    exipiring_date = models.DateField()

    def __str__(self) -> str:
        return self.exipiring_date


class Dispatch(models.Model):
    prosuct = models.ForeignKey(Product, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)

    def __str__(self) -> str:
        return self.name


class Demanders(models.Model):
    dispatch = models.ForeignKey(Dispatch, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)

    def __str__(self) -> str:
        return self.name


class Dispancing(models.Model):
    prosuct = models.ForeignKey(Product, on_delete=models.CASCADE)
    demand = models.ForeignKey(Demanders, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)

    def __str__(self) -> str:
        return self.name

class Patients(models.Model):
    dispance = models.ForeignKey(Dispancing, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    

    def __str__(self) -> str:
        return self.name
