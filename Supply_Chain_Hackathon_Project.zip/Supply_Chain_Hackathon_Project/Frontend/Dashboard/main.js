//responsive sidebar
document.addEventListener("DOMContentLoaded", function() {
    const navToggle = document.getElementById('nav-toggle');
    const navbar = document.getElementById('navbar');
    const bodyPd = document.getElementById('body-pd');

    navToggle.addEventListener('click', () => {
        navbar.classList.toggle('expander');
        bodyPd.classList.toggle('body-pd');
    });
});

//Responsive Header
document.addEventListener('DOMContentLoaded', function() {
  const menuToggle = document.getElementById('nav-toggle');
  const body = document.body;
  const header = document.querySelector('.header');

  menuToggle.addEventListener('click', function() {
      body.classList.toggle('expander');
      header.classList.toggle('header-small');
  });
});

//SubMenu DropDown 
const linkCollapse = document.getElementsByClassName('collapse__link')
var i

for(i=0;i<linkCollapse.length;i++){
  linkCollapse[i].addEventListener('click', function(){
    const collapseMenu = this.nextElementSibling
    collapseMenu.classList.toggle('showCollapse')

    const rotate = collapseMenu.previousElementSibling
    rotate.classList.toggle('rotate')
  })
}
//document.addEventListener('DOMContentLoaded', function() {
  //const collapseLinks = document.querySelectorAll('.collapse__link');

  //collapseLinks.forEach(function(link) {
      //link.addEventListener('click', function(event) {
          //event.stopPropagation();
          //const menu = link.nextElementSibling;
          //menu.classList.toggle('active'); 
          //link.classList.toggle('rotate'); 
      //});
  //});
//});


//Dropdown Menu
document.addEventListener('DOMContentLoaded', function() {
  const menuDropdown = document.getElementById('collapse__menu');
  const menuSubMenu = document.getElementById('collapse__sublink');

  teamDropdown.addEventListener('click', function() {
      teamSubMenu.classList.toggle('active');
  });
});

//Notification Menu Dropdown
document.addEventListener('DOMContentLoaded', function() {
  const notificationIcon = document.querySelector('.header__notification');
  const dropdownWrapper = document.querySelector('.dropdown__wrapper');

  notificationIcon.addEventListener('click', function() {
      dropdownWrapper.classList.toggle('hide');
      dropdownWrapper.classList.toggle('dropdown__wrapper--fade-in');
  });

  document.addEventListener('click', function(event) {
      if (!notificationIcon.contains(event.target) && !dropdownWrapper.contains(event.target)) {
          dropdownWrapper.classList.add('hide');
          dropdownWrapper.classList.remove('dropdown__wrapper--fade-in');
      }
  });
});



